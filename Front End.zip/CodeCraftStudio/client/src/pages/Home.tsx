import { useState, useRef, useEffect } from 'react';
import CodeEditor from '@/components/CodeEditor';
import Console from '@/components/Console';
import Toolbar from '@/components/Toolbar';
import { useToast } from "@/hooks/use-toast";
import { runCode, generateCode } from '@/lib/api';

export default function Home() {
  const [code, setCode] = useState<string>(
    '# Write your Python code here...\n\ndef fibonacci(n):\n    # Calculate the nth Fibonacci number\n    if n <= 1:\n        return n\n    else:\n        return fibonacci(n-1) + fibonacci(n-2)\n\n# TODO: Implement more efficient version using memoization\n\n# Print first 10 Fibonacci numbers\nfor i in range(10):\n    print(fibonacci(i))\n'
  );
  const [output, setOutput] = useState<string[]>(['// Run your code to see output here']);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [statusText, setStatusText] = useState<string>('');
  const editorContainerRef = useRef<HTMLDivElement>(null);
  const consoleContainerRef = useRef<HTMLDivElement>(null);
  const resizeHandleRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    const resizeHandle = resizeHandleRef.current;
    const editorContainer = editorContainerRef.current;
    const consoleContainer = consoleContainerRef.current;
    
    if (!resizeHandle || !editorContainer || !consoleContainer) return;
    
    let isResizing = false;
    
    const handleMouseDown = (e: MouseEvent) => {
      isResizing = true;
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      e.preventDefault();
    };
    
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;
      
      const containerWidth = document.body.clientWidth;
      const newWidth = (e.clientX / containerWidth) * 100;
      
      // Limit resize between 10% and 90%
      if (newWidth > 10 && newWidth < 90) {
        editorContainer.style.width = `${newWidth}%`;
        consoleContainer.style.width = `${100 - newWidth}%`;
      }
    };
    
    const handleMouseUp = () => {
      isResizing = false;
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
    
    resizeHandle.addEventListener('mousedown', handleMouseDown);
    
    return () => {
      resizeHandle.removeEventListener('mousedown', handleMouseDown);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  // Handle Run button click
  const handleRun = async () => {
    try {
      setIsRunning(true);
      setStatusText('Running code...');
      setOutput(['// Executing code...']);
      
      const result = await runCode(code);
      
      // Update console output with result
      setOutput(result.output.split('\n'));
      
      toast({
        title: "Success",
        description: "Code executed successfully",
        variant: "default",
      });
    } catch (error) {
      let errorMsg = "Failed to execute code";
      if (error instanceof Error) errorMsg = error.message;
      
      setOutput([`Error: ${errorMsg}`]);
      
      toast({
        title: "Error",
        description: errorMsg,
        variant: "destructive",
      });
    } finally {
      setIsRunning(false);
      setStatusText('');
    }
  };
  
  // Handle AFK button click
  const handleAFK = async () => {
    try {
      setIsGenerating(true);
      setStatusText('Generating code...');
      
      // Copy current code to clipboard
      await navigator.clipboard.writeText(code);
      setOutput(['✓ Code copied to clipboard']);
      
      // Generate completed code
      const result = await generateCode(code);
      
      // Update editor content
      setCode(result.code);
      setOutput(prev => [...prev, '✅ Code completed and pasted']);
      
      toast({
        title: "Success",
        description: "Code completed successfully",
        variant: "default",
      });
    } catch (error) {
      let errorMsg = "Failed to complete code";
      if (error instanceof Error) errorMsg = error.message;
      
      setOutput([`Error: ${errorMsg}`]);
      
      toast({
        title: "Error",
        description: errorMsg,
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
      setStatusText('');
    }
  };

  return (
    <div className="bg-[#1E1E1E] text-[#E8EAED] font-sans h-screen overflow-hidden flex flex-col">
      <Toolbar 
        onRun={handleRun} 
        onAFK={handleAFK} 
        isRunning={isRunning} 
        isGenerating={isGenerating}
        statusText={statusText}
      />
      
      <div className="flex flex-1 overflow-hidden">
        <div 
          ref={editorContainerRef}
          className="w-1/2 flex flex-col bg-[#1E1E1E] border-r border-gray-700"
        >
          <div className="py-1 px-2 bg-[#252526] border-b border-gray-700 text-sm text-[#9AA0A6]">
            main.py
          </div>
          <CodeEditor code={code} setCode={setCode} />
        </div>
        
        <div 
          ref={resizeHandleRef}
          className="cursor-col-resize bg-[#333] w-1 hover:bg-[#4285F4] transition-colors"
        />
        
        <div 
          ref={consoleContainerRef}
          className="w-1/2 flex flex-col overflow-hidden"
        >
          <div className="py-1 px-2 bg-[#252526] border-b border-gray-700 text-sm text-[#9AA0A6]">
            Console Output
          </div>
          <Console output={output} />
        </div>
      </div>
    </div>
  );
}
