import { useEffect, useState } from 'react';

interface ToastProps {
  message: string;
  type?: 'info' | 'success' | 'error';
  duration?: number;
  onClose: () => void;
}

export default function Toast({ message, type = 'info', duration = 2000, onClose }: ToastProps) {
  const [isVisible, setIsVisible] = useState(true);
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onClose, 300); // Wait for fade out animation before removing
    }, duration);
    
    return () => clearTimeout(timer);
  }, [duration, onClose]);
  
  const getBackgroundColor = () => {
    switch(type) {
      case 'success': return 'bg-[#0F9D58]';
      case 'error': return 'bg-[#DB4437]';
      default: return 'bg-gray-800';
    }
  };
  
  return (
    <div 
      className={`fixed bottom-4 right-4 px-6 py-3 rounded text-white ${getBackgroundColor()} 
        transition-opacity duration-300 shadow-lg ${isVisible ? 'opacity-100' : 'opacity-0'}`}
    >
      {message}
    </div>
  );
}
