import { useEffect, useRef } from 'react';
import * as monaco from 'monaco-editor';

// Initialize monaco themes
monaco.editor.defineTheme('vs-dark-custom', {
  base: 'vs-dark',
  inherit: true,
  rules: [
    { token: 'comment', foreground: '6A9955' },
    { token: 'keyword', foreground: '569CD6' },
    { token: 'string', foreground: 'CE9178' },
    { token: 'function', foreground: 'DCDCAA' },
    { token: 'variable', foreground: '9CDCFE' },
  ],
  colors: {
    'editor.background': '#1E1E1E',
    'editor.foreground': '#E8EAED',
    'editorLineNumber.foreground': '#6A6A6A',
    'editorLineNumber.activeForeground': '#CCCCCC',
    'editorGutter.background': '#252526',
  }
});

interface CodeEditorProps {
  code: string;
  setCode: (code: string) => void;
}

export default function CodeEditor({ code, setCode }: CodeEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const monacoEditorRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);

  useEffect(() => {
    if (editorRef.current && !monacoEditorRef.current) {
      monacoEditorRef.current = monaco.editor.create(editorRef.current, {
        value: code,
        language: 'python',
        theme: 'vs-dark-custom',
        automaticLayout: true,
        minimap: {
          enabled: false
        },
        scrollBeyondLastLine: false,
        fontSize: 14,
        fontFamily: '"Fira Code", monospace',
        lineNumbers: 'on',
        lineNumbersMinChars: 3,
        padding: {
          top: 8,
          bottom: 8
        },
        renderLineHighlight: 'all',
        scrollbar: {
          verticalScrollbarSize: 10,
          horizontalScrollbarSize: 10
        }
      });

      // Handle content changes
      monacoEditorRef.current.onDidChangeModelContent(() => {
        if (monacoEditorRef.current) {
          setCode(monacoEditorRef.current.getValue());
        }
      });
    }

    return () => {
      if (monacoEditorRef.current) {
        monacoEditorRef.current.dispose();
        monacoEditorRef.current = null;
      }
    };
  }, []);

  // Update editor content when code prop changes
  useEffect(() => {
    if (monacoEditorRef.current && monacoEditorRef.current.getValue() !== code) {
      monacoEditorRef.current.setValue(code);
    }
  }, [code]);

  return (
    <div className="relative flex-1 overflow-hidden">
      <div ref={editorRef} className="absolute inset-0" />
    </div>
  );
}
