import { useRef, useEffect } from 'react';

interface ConsoleProps {
  output: string[];
}

export default function Console({ output }: ConsoleProps) {
  const consoleRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to the bottom when output changes
  useEffect(() => {
    if (consoleRef.current) {
      consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
    }
  }, [output]);

  return (
    <div 
      ref={consoleRef}
      className="flex-1 font-mono text-sm p-2 overflow-auto bg-[#1a1a1a] whitespace-pre-wrap"
    >
      {output.map((line, index) => (
        <div key={index} className={
          line.startsWith('✓') || line.startsWith('✅') 
            ? 'text-[#0F9D58]' 
            : line.startsWith('Error:') 
              ? 'text-[#DB4437]' 
              : line.startsWith('//') 
                ? 'text-gray-500'
                : ''
        }>
          {line}
        </div>
      ))}
    </div>
  );
}
