import { apiRequest } from './queryClient';

interface RunCodeResponse {
  output: string;
}

interface GenerateCodeResponse {
  code: string;
}

// Function to run code
export async function runCode(code: string, language: string = 'python'): Promise<RunCodeResponse> {
  const response = await apiRequest('POST', '/api/run', { code, language });
  return response.json();
}

// Function to generate code completion
export async function generateCode(code: string, language: string = 'python'): Promise<GenerateCodeResponse> {
  const response = await apiRequest('POST', '/api/generate', { code, language });
  return response.json();
}
