import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { codeRunSchema, codeGenerateSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoint to run code
  app.post("/api/run", async (req: Request, res: Response) => {
    try {
      const parseResult = codeRunSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid request body",
          errors: parseResult.error.errors
        });
      }
      
      const { code, language } = parseResult.data;
      
      // Simulate code execution with delay to mimic processing time
      const output = await storage.executeCode(code, language);
      
      return res.status(200).json({ output });
    } catch (error) {
      console.error("Error running code:", error);
      return res.status(500).json({ 
        message: "Failed to run code",
        error: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // API endpoint to generate code completion
  app.post("/api/generate", async (req: Request, res: Response) => {
    try {
      const parseResult = codeGenerateSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid request body",
          errors: parseResult.error.errors
        });
      }
      
      const { code, language } = parseResult.data;
      
      // Generate code completion with delay to mimic processing time
      const completedCode = await storage.generateCode(code, language);
      
      return res.status(200).json({ code: completedCode });
    } catch (error) {
      console.error("Error generating code:", error);
      return res.status(500).json({ 
        message: "Failed to generate code",
        error: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
