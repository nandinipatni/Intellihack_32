import { users, type User, type InsertUser, code, type Code, type InsertCode } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getCode(id: number): Promise<Code | undefined>;
  createCode(codeEntry: InsertCode): Promise<Code>;
  updateCode(id: number, content: string): Promise<Code | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private codeEntries: Map<number, Code>;
  private userIdCounter: number;
  private codeIdCounter: number;

  constructor() {
    this.users = new Map();
    this.codeEntries = new Map();
    this.userIdCounter = 1;
    this.codeIdCounter = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getCode(id: number): Promise<Code | undefined> {
    return this.codeEntries.get(id);
  }

  async createCode(insertCode: InsertCode): Promise<Code> {
    const id = this.codeIdCounter++;
    const codeEntry: Code = { ...insertCode, id };
    this.codeEntries.set(id, codeEntry);
    return codeEntry;
  }

  async updateCode(id: number, content: string): Promise<Code | undefined> {
    const codeEntry = this.codeEntries.get(id);
    if (!codeEntry) return undefined;
    
    const updatedEntry = { ...codeEntry, content };
    this.codeEntries.set(id, updatedEntry);
    return updatedEntry;
  }
  
  // Mock execution of code and return output
  async executeCode(code: string, language: string): Promise<string> {
    // This is a mock implementation that returns predefined outputs for demonstration
    if (language === "python") {
      if (code.includes("fibonacci")) {
        return "0\n1\n1\n2\n3\n5\n8\n13\n21\n34";
      }
      return "Hello, World!";
    }
    return "Execution complete";
  }
  
  // Mock code generation/completion
  async generateCode(code: string, language: string): Promise<string> {
    // This is a mock implementation that returns predefined code completions for demonstration
    if (language === "python" && code.includes("fibonacci")) {
      return `# Python Fibonacci Implementation with Memoization

# Initialize cache for memoization
memo = {}

def fibonacci(n):
    """
    Calculate the nth Fibonacci number efficiently using memoization.
    Time Complexity: O(n)
    Space Complexity: O(n)
    """
    # Check if we've already calculated this value
    if n in memo:
        return memo[n]
    
    # Base cases
    if n <= 1:
        memo[n] = n
        return n
    
    # Recursive case with memoization
    memo[n] = fibonacci(n-1) + fibonacci(n-2)
    return memo[n]

# Print first 10 Fibonacci numbers
print("First 10 Fibonacci numbers:")
for i in range(10):
    result = fibonacci(i)
    print(f"fibonacci({i}) = {result}")

# Calculate a larger value to demonstrate efficiency
n = 35
print(f"\\nFibonacci of {n} is {fibonacci(n)}")
`;
    }
    
    return code + "\n\n# Code completion generated";
  }
}

export const storage = new MemStorage();
