import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const code = pgTable("code", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  language: text("language").notNull().default("python"),
  userId: integer("user_id").references(() => users.id),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertCodeSchema = createInsertSchema(code).pick({
  content: true,
  language: true,
  userId: true,
});

export const codeRunSchema = z.object({
  code: z.string(),
  language: z.string().default("python"),
});

export const codeGenerateSchema = z.object({
  code: z.string(),
  language: z.string().default("python"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertCode = z.infer<typeof insertCodeSchema>;
export type User = typeof users.$inferSelect;
export type Code = typeof code.$inferSelect;
